var SerialPort = require("serialport");
function sendSMS(){
  var serialPort = new SerialPort("/dev/ttyUSB0", {
      baudRate: 9600
  });
  
  serialPort.on("open", async function () {
      console.log('Serial communication open');
      serialPort.write("AT\r",11);
      await sleep(100);
      serialPort.write("AT+CSCS=\"gsm\"\r",15);
      await sleep(100);
      serialPort.write("AT+CSCA=\"<Service center number>\"\r",19);
      await sleep(100);
      serialPort.write("AT+CMGS=\"<Receiver's number>\"\r\n\0",23);
      await sleep(1000);
      serialPort.write("test\r",6);
      await sleep(1000);
      serialPort.write("\r",0);
      await sleep(100);
      serialPort.write("\x1A",2);
      serialPort.on('data', function(data) {
          console.log("Received data: " + data.toString());
      });
  });
  }
  function sleep(ms){
  return new Promise(resolve=>{
      setTimeout(resolve,ms)
  })
  }
  sendSMS();