/* const express = require('express');
const app = express();
var port = 3000; 


app.listen(port, function () {
  console.log('Example app listening on port http://0.0.0.0:' + port + '!');
});
*/

var SerialPort = require("serialport");
function sendSMS(){
  var serialPort = new SerialPort("/dev/ttyUSB0", {
      baudRate: 9600
  });
  
  serialPort.on("open", async function () {
      console.log('Serial communication open');

      serialPort.write("AT\r");
      await sleep(100);     
      serialPort.write("AT+CPOWD=1\r");
      await sleep(100);
      
      serialPort.on('data', function(data) {
          console.log("Received data: " + data.toString());
      });
  });
  }
  function sleep(ms){
  return new Promise(resolve=>{
      setTimeout(resolve,ms)
  })
  }
  sendSMS();
/* const SerialPort = require('serialport');
// open the port
var port = new SerialPort('/dev/ttyUSB0', {
  baudRate: 9600
});
port.write('AT+', function(err) {
  if (err) {
    return console.log('Error on write: ', err.message)
  }
  console.log('message written')
  // Switches the port into "flowing mode"
port.on('data', function (data) {
  console.log('Data:', data.toString())
})
})

// Open errors will be emitted as an error event
port.on('error', function(err) {
  console.log('Error: ', err.message)
}) */


// Promise approach
/* 
var arduinoCOMPort = "/dev/ttyACM0";

var arduinoSerialPort = new SerialPort(arduinoCOMPort, {  
 baudrate: 9600
});

arduinoSerialPort.on('open',function() {
  console.log('Serial Port ' + arduinoCOMPort + ' is opened.');
});

app.get('/', function (req, res) {

    return res.send('Working');
 
})

app.get('/:action', function (req, res) {
    
   var action = req.params.action || req.param('action');
    
    if(action == 'led'){
        arduinoSerialPort.write("w");
        return res.send('Led light is on!');
    } 
    if(action == 'off') {
        arduinoSerialPort.write("t");
        return res.send("Led light is off!");
    }
    
    return res.send('Action: ' + action);
 
}); */





//parser.on('data', function(data){ console.log(data)})


// The parser will emit any string response

/*

// Require the serialport node module
var serialport = require('serialport');
var SerialPort = serialport.SerialPort;
// Open the port
var port = new SerialPort("/dev/ttyACM0", {//"/dev/ttyACM0"
    baudrate: 9600,
    parser: serialport.parsers.readline("\n")
},false);
// Read the port data
port.on("open", function () {
    console.log('open');
    port.on('data', function(data) {
        console.log(data);
    });
});*/
/*
const SerialPort = require('serialport');// include the library
const WebSocketServer = require('ws').Server;
const SERVER_PORT = 7000;               // port number for the webSocket server
const wss = new WebSocketServer({port: SERVER_PORT}); // the webSocket server
var connections = new Array;          // list of connections to the server
const Readline = SerialPort.parsers.Readline;

wss.on('connection', handleConnection);

const myPort = new SerialPort('COM3', {
  baudRate: 115200,
  parser: SerialPort.parsers.readline('\r\n')
});

myPort.on('open', showPortOpen);
myPort.on('close', showPortClose);
myPort.on('error', showError);

myPort.on('data', data => readSerialData(data.toString()));


// ...

function broadcast(data) {
    console.log(data);
    for (myConnection in connections) {
        connections[myConnection].send(JSON.stringify(data));
    }
}

// ...

function readSerialData(data) {
   // if there are webSocket connections, send the serial data
   // to all of them:
   if (connections.length > 0) {
     broadcast(data);
   }
}

// ...

*/