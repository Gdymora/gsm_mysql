// index.js
require('./app/index')